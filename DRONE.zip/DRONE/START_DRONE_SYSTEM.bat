@echo off
chcp 65001 > nul
cd /d "%~dp0"

echo =========================================
echo     🚁 DRONE CONTROL SYSTEM
echo      Complete Startup Script
echo =========================================
echo.

rem Set UTF-8 encoding
for /f "tokens=2 delims==" %%i in ('wmic os get codeset /value') do set CODESET=%%i
if not "%CODESET%"=="65001" (
    echo Setting UTF-8 encoding...
    chcp 65001 > nul
)

echo Available options:
echo.
echo 🔧 UTILITIES:
echo    [1] Check system requirements
echo    [2] Setup X11 display
echo    [3] Fix path issues
echo.
echo 🚀 SYSTEM CONTROL:
echo    [4] Start system (Gazebo + ROS2)
echo    [5] Takeoff drone
echo    [6] Land drone
echo.
echo 🎮 DRONE CONTROL:
echo    [7] Keyboard control (Menu-based)
echo    [8] Advanced teleoperation (Real-time)
echo    [9] GUI control (Recommended)
echo.
echo 📦 QUICK START:
echo    [0] Complete system startup (Auto)
echo.
echo    [Q] Quit
echo.

set /p choice="Select option: "

if "%choice%"=="1" (
    echo Starting requirements check...
    if exist "utils\check_requirements.bat" (
        call "utils\check_requirements.bat"
    ) else if exist "0_check_gui_requirements.bat" (
        call "0_check_gui_requirements.bat"
    ) else (
        echo Requirements check file not found.
    )
    goto menu
)

if "%choice%"=="2" (
    echo Starting X11 setup...
    if exist "utils\setup_x11.bat" (
        call "utils\setup_x11.bat"
    ) else if exist "setup_x11.bat" (
        call "setup_x11.bat"
    ) else (
        echo X11 setup file not found.
    )
    goto menu
)

if "%choice%"=="3" (
    echo Starting path fix...
    if exist "utils\setup_path_fix.bat" (
        call "utils\setup_path_fix.bat"
    ) else if exist "setup_path_fix.bat" (
        call "setup_path_fix.bat"
    ) else (
        echo Path fix file not found.
    )
    goto menu
)

if "%choice%"=="4" (
    echo Starting system...
    if exist "system\start_system.bat" (
        call "system\start_system.bat"
    ) else if exist "1_start_system.bat" (
        call "1_start_system.bat"
    ) else (
        echo System start file not found.
    )
    goto menu
)

if "%choice%"=="5" (
    echo Drone takeoff...
    if exist "system\takeoff.bat" (
        call "system\takeoff.bat"
    ) else if exist "2_takeoff.bat" (
        call "2_takeoff.bat"
    ) else (
        echo Takeoff file not found.
    )
    goto menu
)

if "%choice%"=="6" (
    echo Drone landing...
    if exist "system\landing.bat" (
        call "system\landing.bat"
    ) else if exist "4_landing.bat" (
        call "4_landing.bat"
    ) else (
        echo Landing file not found.
    )
    goto menu
)

if "%choice%"=="7" (
    echo Starting keyboard control...
    if exist "control\keyboard_control.bat" (
        call "control\keyboard_control.bat"
    ) else if exist "3_keyboard_control.bat" (
        call "3_keyboard_control.bat"
    ) else (
        echo Keyboard control file not found.
    )
    goto menu
)

if "%choice%"=="8" (
    echo Starting advanced teleoperation...
    if exist "control\advanced_teleop.bat" (
        call "control\advanced_teleop.bat"
    ) else if exist "5_advanced_teleop.bat" (
        call "5_advanced_teleop.bat"
    ) else (
        echo Advanced teleop file not found.
    )
    goto menu
)

if "%choice%"=="9" (
    echo Starting GUI control...
    if exist "control\gui_teleop.bat" (
        call "control\gui_teleop.bat"
    ) else if exist "6_gui_teleop_en.bat" (
        call "6_gui_teleop_en.bat"
    ) else if exist "6_gui_teleop.bat" (
        call "6_gui_teleop.bat"
    ) else (
        echo GUI control file not found.
    )
    goto menu
)

if "%choice%"=="0" (
    echo Starting complete system...
    if exist "system\start_gui_system.bat" (
        call "system\start_gui_system.bat"
    ) else if exist "start_gui_system_en.bat" (
        call "start_gui_system_en.bat"
    ) else if exist "start_gui_system.bat" (
        call "start_gui_system.bat"
    ) else (
        echo Complete system file not found.
    )
    goto menu
)

if /i "%choice%"=="q" (
    echo Exiting...
    exit
)

:menu
echo.
echo Press any key to return to menu...
pause > nul
goto start

:start
cls
goto :eof 