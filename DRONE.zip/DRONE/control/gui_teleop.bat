@echo off
chcp 65001 > nul
cd /d "%~dp0"

echo =========================================
echo     Drone GUI Teleoperation System
echo            (English Version)
echo =========================================
echo.

rem Set UTF-8 encoding
for /f "tokens=2 delims==" %%i in ('wmic os get codeset /value') do set CODESET=%%i
if not "%CODESET%"=="65001" (
    echo Setting UTF-8 encoding...
    chcp 65001 > nul
)

echo Checking system requirements...

rem Check if X11 display is available
echo Checking X11 display...
wsl test -S "/tmp/.X11-unix/X0"
if %ERRORLEVEL% neq 0 (
    echo.
    echo X11 display not available!
    echo Please set up X11 display server first.
    echo You can use utils/setup_x11.bat for help.
    echo.
    pause
    exit /b 1
)

rem Check ROS2 environment
echo Checking ROS2 environment...
wsl bash -c "source /opt/ros/humble/setup.bash 2>/dev/null && ros2 topic list | grep -q ppo"
if %ERRORLEVEL% neq 0 (
    echo.
    echo ROS2 system not running or PPO topics not available!
    echo Please start the system first:
    echo 1. Run system/start_system.bat (or 1_start_system.bat)
    echo 2. Run system/takeoff.bat (or 2_takeoff.bat)
    echo.
    pause
    exit /b 1
)

echo Starting GUI teleoperation system...
echo Please wait while the GUI control window opens...

rem Execute GUI control script
if exist "scripts\gui_teleop_control.py" (
    wsl bash -c "cd '%CD%' && source /opt/ros/humble/setup.bash && export DISPLAY=:0 && export LANG=en_US.UTF-8 && export LC_ALL=en_US.UTF-8 && python3 scripts/gui_teleop_control.py"
) else if exist "gui_teleop_control_en.py" (
    wsl bash -c "cd '%CD%' && source /opt/ros/humble/setup.bash && export DISPLAY=:0 && export LANG=en_US.UTF-8 && export LC_ALL=en_US.UTF-8 && python3 gui_teleop_control_en.py"
) else (
    echo GUI control script not found!
    echo Looking for: scripts/gui_teleop_control.py or gui_teleop_control_en.py
    pause
    exit /b 1
)

if %ERRORLEVEL% neq 0 (
    echo ❌ Failed to start GUI system.
    echo.
    echo Troubleshooting:
    echo 1. Check if WSL2 is installed
    echo 2. Check if ROS2 Humble is installed  
    echo 3. Check if X11 server is running (VcXsrv, X410, WSLg etc)
    echo 4. Make sure system/start_system.bat and system/takeoff.bat were executed first
    echo 5. Run utils/check_requirements.bat to verify all dependencies
    echo.
    pause
    exit /b 1
)

echo GUI system started successfully.
pause 